package collageBuilderMockup;

import java.util.List;

public class APIResponse {
    SearchInfo searchInformation;
    Item[] items;

    public SearchInfo getSearchInformation() {
        return searchInformation;
    }

    public Item[] getItems() {
        return items;
    }
}
