package collageBuilderMockup;

public class SearchInfo {
    double searchTime;
    String formattedSearchTime;

    public double getSearchTime() {
        return searchTime;
    }

    public String getFormattedSearchTime() {
        return formattedSearchTime;
    }
}
